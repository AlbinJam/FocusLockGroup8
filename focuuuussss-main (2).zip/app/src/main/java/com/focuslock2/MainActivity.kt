package com.focuslock2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.UserPoints
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var database: AppLockDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        database = AppLockDatabase.getDatabase(this)

        val pointsDisplay = findViewById<TextView>(R.id.pointsDisplay)
        val btnManageApps = findViewById<Button>(R.id.btnManageApps)
        val btnSetSchedules = findViewById<Button>(R.id.btnSetSchedules)
        val btnViewLogs = findViewById<Button>(R.id.btnViewLogs)
        val btnParentSettings = findViewById<Button>(R.id.btnParentSettings)

        // Observe points changes
        lifecycleScope.launch {
            database.userPointsDao().getPoints().collect { points ->
                if (points != null) {
                    pointsDisplay.text = "Points: ${points.points} (Today: ${points.earnedToday})"
                } else {
                    // Initialize points if not exist
                    database.userPointsDao().insertPoints(UserPoints())
                }
            }
        }

        btnManageApps.setOnClickListener {
            startActivity(Intent(this, ManageAppsActivity::class.java))
        }

        btnSetSchedules.setOnClickListener {
            startActivity(Intent(this, SetTimeoutAppsActivity::class.java))
        }

        btnViewLogs.setOnClickListener {
            startActivity(Intent(this, CompletionLogsActivity::class.java))
        }

        btnParentSettings.setOnClickListener {
            startActivity(Intent(this, ParentDashboardActivity::class.java))
        }

        // Start app lock service
        val serviceIntent = Intent(this, AppLockService::class.java)
        startService(serviceIntent)
    }
}
