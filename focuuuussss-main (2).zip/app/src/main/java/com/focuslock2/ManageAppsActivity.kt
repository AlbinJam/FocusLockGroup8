package com.focuslock2

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.LockedApp
import kotlinx.coroutines.launch

class ManageAppsActivity : AppCompatActivity() {
    private lateinit var database: AppLockDatabase
    private lateinit var packageManager: PackageManager
    private lateinit var appAdapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_apps)

        database = AppLockDatabase.getDatabase(this)
        packageManager = packageManager

        val listView = findViewById<ListView>(R.id.appsListView)
        val btnAddApp = findViewById<Button>(R.id.btnAddApp)

        appAdapter = AppListAdapter(this, mutableListOf(), database)
        listView.adapter = appAdapter

        loadInstalledApps()

        btnAddApp.setOnClickListener {
            showAppSelectionDialog()
        }
    }

    private fun loadInstalledApps() {
        lifecycleScope.launch {
            database.lockedAppDao().getAllLockedApps().collect { apps ->
                appAdapter.clear()
                appAdapter.addAll(apps)
                appAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun showAppSelectionDialog() {
        val installedApps = getInstalledApps()
        val appNames = installedApps.map { it.loadLabel(packageManager).toString() }.toTypedArray()

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Select App to Lock")
            .setItems(appNames) { _, which ->
                val selectedApp = installedApps[which]
                val lockedApp = LockedApp(
                    packageName = selectedApp.packageName,
                    appName = selectedApp.loadLabel(packageManager).toString(),
                    isLocked = true
                )
                lifecycleScope.launch {
                    database.lockedAppDao().insertApp(lockedApp)
                    Toast.makeText(this@ManageAppsActivity, "App added to lock list", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun getInstalledApps(): List<ApplicationInfo> {
        return packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName && it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
    }
}
