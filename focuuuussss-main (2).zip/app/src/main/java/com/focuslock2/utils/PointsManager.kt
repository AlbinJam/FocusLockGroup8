package com.focuslock2.utils

import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.UserPoints
import java.util.*

class PointsManager(private val database: AppLockDatabase) {

    suspend fun addPoints(amount: Int) {
        val currentPoints = database.userPointsDao().getPointsSync()
        if (currentPoints != null) {
            database.userPointsDao().addPoints(amount)
        } else {
            database.userPointsDao().insertPoints(
                UserPoints(
                    id = 1,
                    points = amount,
                    earnedToday = amount,
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun resetDailyPoints() {
        database.userPointsDao().resetDailyPoints(System.currentTimeMillis())
    }

    suspend fun getPoints(): UserPoints? {
        return database.userPointsDao().getPointsSync()
    }

    fun shouldResetDaily(lastUpdated: Long): Boolean {
        val lastDate = Calendar.getInstance().apply { timeInMillis = lastUpdated }
        val today = Calendar.getInstance()
        return lastDate.get(Calendar.DAY_OF_YEAR) != today.get(Calendar.DAY_OF_YEAR)
    }
}
