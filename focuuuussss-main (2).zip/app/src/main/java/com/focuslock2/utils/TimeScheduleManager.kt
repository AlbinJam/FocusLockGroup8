package com.focuslock2.utils

import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.LockSchedule
import java.text.SimpleDateFormat
import java.util.*

class TimeScheduleManager(private val database: AppLockDatabase) {

    suspend fun isAppLockedNow(packageName: String): Boolean {
        val schedules = database.lockScheduleDao().getSchedulesForApp(packageName)
        var isLocked = false

        schedules.collect { scheduleList ->
            val currentTime = getCurrentTimeString()
            val currentDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1

            for (schedule in scheduleList) {
                if (!schedule.isActive) continue

                val daysArray = schedule.days.split(",").map { it.toIntOrNull() ?: 0 }
                if (currentDay !in daysArray) continue

                if (isTimeBetween(currentTime, schedule.startTime, schedule.endTime)) {
                    isLocked = true
                    break
                }
            }
        }

        return isLocked
    }

    private fun isTimeBetween(current: String, start: String, end: String): Boolean {
        return current >= start && current <= end
    }

    private fun getCurrentTimeString(): String {
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        return format.format(Date())
    }
}
