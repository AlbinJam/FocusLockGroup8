package com.focuslock2.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Update
import androidx.room.Delete
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "locked_apps")
data class LockedApp(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val isLocked: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "lock_schedules")
data class LockSchedule(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val packageName: String,
    val startTime: String, // Format: "HH:mm"
    val endTime: String,   // Format: "HH:mm"
    val isActive: Boolean = true,
    val days: String = "0,1,2,3,4,5,6" // Comma-separated day indices (0=Sunday)
)

@Entity(tableName = "user_points")
data class UserPoints(
    @PrimaryKey
    val id: Int = 1,
    val points: Int = 0,
    val earnedToday: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Dao
interface LockedAppDao {
    @Insert
    suspend fun insertApp(app: LockedApp)

    @Update
    suspend fun updateApp(app: LockedApp)

    @Delete
    suspend fun deleteApp(app: LockedApp)

    @Query("SELECT * FROM locked_apps")
    fun getAllLockedApps(): Flow<List<LockedApp>>

    @Query("SELECT * FROM locked_apps WHERE isLocked = 1")
    fun getActiveLockedApps(): Flow<List<LockedApp>>

    @Query("SELECT * FROM locked_apps WHERE packageName = :packageName")
    suspend fun getAppByPackage(packageName: String): LockedApp?

    @Query("DELETE FROM locked_apps WHERE packageName = :packageName")
    suspend fun deleteAppByPackage(packageName: String)
}

@Dao
interface LockScheduleDao {
    @Insert
    suspend fun insertSchedule(schedule: LockSchedule)

    @Update
    suspend fun updateSchedule(schedule: LockSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: LockSchedule)

    @Query("SELECT * FROM lock_schedules")
    fun getAllSchedules(): Flow<List<LockSchedule>>

    @Query("SELECT * FROM lock_schedules WHERE packageName = :packageName")
    fun getSchedulesForApp(packageName: String): Flow<List<LockSchedule>>

    @Query("DELETE FROM lock_schedules WHERE packageName = :packageName")
    suspend fun deleteSchedulesForApp(packageName: String)
}

@Dao
interface UserPointsDao {
    @Insert
    suspend fun insertPoints(points: UserPoints)

    @Update
    suspend fun updatePoints(points: UserPoints)

    @Query("SELECT * FROM user_points WHERE id = 1")
    fun getPoints(): Flow<UserPoints?>

    @Query("SELECT * FROM user_points WHERE id = 1")
    suspend fun getPointsSync(): UserPoints?

    @Query("UPDATE user_points SET points = points + :amount, earnedToday = earnedToday + :amount WHERE id = 1")
    suspend fun addPoints(amount: Int)

    @Query("UPDATE user_points SET points = 0 WHERE id = 1")
    suspend fun resetPoints()

    @Query("UPDATE user_points SET earnedToday = 0, lastUpdated = :timestamp WHERE id = 1")
    suspend fun resetDailyPoints(timestamp: Long)
}
