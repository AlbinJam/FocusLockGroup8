package com.focuslock2.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [LockedApp::class, LockSchedule::class, UserPoints::class], version = 1, exportSchema = false)
abstract class AppLockDatabase : RoomDatabase() {
    abstract fun lockedAppDao(): LockedAppDao
    abstract fun lockScheduleDao(): LockScheduleDao
    abstract fun userPointsDao(): UserPointsDao

    companion object {
        @Volatile
        private var INSTANCE: AppLockDatabase? = null

        fun getDatabase(context: Context): AppLockDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppLockDatabase::class.java,
                    "applock_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
