package com.focuslock2

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.lifecycleScope
import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.LockSchedule
import kotlinx.coroutines.launch

class ParentDashboardActivity : ComponentActivity() {
    private lateinit var database: AppLockDatabase
    private lateinit var taskAdapter: TaskListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parent_dashboard)

        database = AppLockDatabase.getDatabase(this)

        val listView = findViewById<ListView>(R.id.tasksListView)
        val btnAddTask = findViewById<Button>(R.id.btnAddTask)
        val taskInput = findViewById<EditText>(R.id.taskInput)

        taskAdapter = TaskListAdapter(this, mutableListOf())
        listView.adapter = taskAdapter

        btnAddTask.setOnClickListener {
            val taskText = taskInput.text.toString()
            if (taskText.isEmpty()) {
                Toast.makeText(this, "Please enter a task", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            taskAdapter.add(taskText)
            taskAdapter.notifyDataSetChanged()
            taskInput.text.clear()
            Toast.makeText(this, "Task added", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun ParentDashboardScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Set Apps", "Set Tasks")
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(selected = selectedTab == index, onClick = { selectedTab = index }) {
                    Text(text = title, modifier = Modifier.padding(16.dp))
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        when(selectedTab) {
            0 -> AppTimeoutManager()
            1 -> TaskManagerUI()
        }
    }
}

@Composable
fun AppTimeoutManager() {
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember {
        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { it.loadLabel(pm).toString() }
    }

    var selectedApps by remember { mutableStateOf(setOf<String>()) }
    var timeoutMap by remember { mutableStateOf(mapOf<String, Long>()) }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(apps) { app ->
            val appName = app.loadLabel(pm).toString()
            val checked = selectedApps.contains(app.packageName)
            Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checked, onCheckedChange = { isChecked ->
                        selectedApps = if(isChecked) selectedApps + app.packageName
                        else selectedApps - app.packageName
                    })
                    Text(text = appName, fontSize = 16.sp, modifier = Modifier.padding(start = 8.dp))
                }
                if(checked) {
                    Row(modifier = Modifier.padding(start = 32.dp), verticalAlignment = Alignment.CenterVertically) {
                        var hours by remember { mutableStateOf(0) }
                        var minutes by remember { mutableStateOf(0) }
                        var seconds by remember { mutableStateOf(0) }

                        NumberPickerUI(value = hours, range = 0..23, label="H") { hours = it }
                        NumberPickerUI(value = minutes, range = 0..59, label="M") { minutes = it }
                        NumberPickerUI(value = seconds, range = 0..59, label="S") { seconds = it }

                        Button(onClick = {
                            timeoutMap = timeoutMap + (app.packageName to ((hours*3600 + minutes*60 + seconds) * 1000L))
                        }, modifier = Modifier.padding(start = 8.dp)) {
                            Text("Set Time")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NumberPickerUI(value: Int, range: IntRange, label: String, onValueChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end=8.dp)) {
        Button(onClick = { if(value>range.first) onValueChange(value-1) }) { Text("-") }
        Text("$value $label", modifier = Modifier.padding(horizontal=4.dp))
        Button(onClick = { if(value<range.last) onValueChange(value+1) }) { Text("+") }
    }
}

@Composable
fun TaskManagerUI() {
    var tasks by remember { mutableStateOf(mutableListOf<String>()) }
    var newTask by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(tasks) { task -> Text(task, fontSize = 16.sp, modifier = Modifier.padding(4.dp)) }
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newTask,
                onValueChange = { newTask = it },
                label = { Text("New Task") },
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                if(newTask.isNotBlank()) {
                    tasks.add(newTask)
                    newTask = ""
                }
            }, modifier = Modifier.padding(start=8.dp)) {
                Text("Add")
            }
        }
    }
}
