package com.focuslock2

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class VerifyAccessActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VerifyAccessScreen() }
    }
}

@Composable
fun VerifyAccessScreen() {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "VERIFY ACCESS", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Parent Email") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (email.isBlank()) {
                    Toast.makeText(context, "Enter email to verify (dummy)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Verified (dummy)", Toast.LENGTH_SHORT).show()
                    context.startActivity(Intent(context, ParentDashboardActivity::class.java))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("DONE")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { Toast.makeText(context, "Resent (dummy)", Toast.LENGTH_SHORT).show() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("RESEND VERIFICATION")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { (context as? ComponentActivity)?.finish() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("BACK TO HOME")
        }
    }
}
