package com.focuslock2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.appcompat.app.AppCompatActivity
import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.LockSchedule
import kotlinx.coroutines.launch

class ScheduleListAdapter(
    context: Context,
    items: MutableList<LockSchedule>,
    private val database: AppLockDatabase
) : ArrayAdapter<LockSchedule>(context, 0, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_schedule, parent, false)

        val schedule = getItem(position) ?: return view
        val scheduleInfo = view.findViewById<TextView>(R.id.scheduleInfo)
        val deleteBtn = view.findViewById<Button>(R.id.deleteScheduleBtn)

        scheduleInfo.text = "${schedule.startTime} - ${schedule.endTime}"

        deleteBtn.setOnClickListener {
            val activity = context as AppCompatActivity
            activity.lifecycleScope.launch {
                database.lockScheduleDao().deleteSchedule(schedule)
                remove(schedule)
                notifyDataSetChanged()
                Toast.makeText(context, "Schedule deleted", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}
