package com.focuslock2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView

class TaskListAdapter(
    context: Context,
    items: MutableList<String>
) : ArrayAdapter<String>(context, 0, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_task, parent, false)

        val task = getItem(position) ?: return view
        val taskText = view.findViewById<TextView>(R.id.taskText)
        val taskCheckbox = view.findViewById<CheckBox>(R.id.taskCheckbox)
        val deleteBtn = view.findViewById<Button>(R.id.deleteTaskBtn)

        taskText.text = task
        deleteBtn.setOnClickListener {
            remove(task)
            notifyDataSetChanged()
        }

        return view
    }
}
