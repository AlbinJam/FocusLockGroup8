package com.focuslock2.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.app.ActivityManager
import android.content.Context
import androidx.lifecycle.lifecycleScope
import com.focuslock2.database.AppLockDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

class AppLockService : Service() {
    private lateinit var database: AppLockDatabase
    private var isRunning = true

    companion object {
        private const val TAG = "AppLockService"
        private const val CHECK_INTERVAL = 500L // Check every 500ms
    }

    override fun onCreate() {
        super.onCreate()
        database = AppLockDatabase.getDatabase(this)
        startLockMonitoring()
    }

    private fun startLockMonitoring() {
        Thread {
            while (isRunning) {
                try {
                    monitorAndLockApps()
                    Thread.sleep(CHECK_INTERVAL)
                } catch (e: Exception) {
                    Log.e(TAG, "Error in monitoring loop", e)
                }
            }
        }.start()
    }

    private fun monitorAndLockApps() {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val tasks = activityManager.getRunningTasks(1)

        if (tasks.isNotEmpty()) {
            val currentPackage = tasks[0].topActivity?.packageName
            if (currentPackage != null && currentPackage != packageName) {
                Thread {
                    try {
                        val lockedApp = database.lockedAppDao().getAppByPackage(currentPackage)
                        if (lockedApp != null && lockedApp.isLocked && isAppLockedBySchedule(currentPackage)) {
                            lockApp(currentPackage)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error checking app lock status", e)
                    }
                }.start()
            }
        }
    }

    private fun isAppLockedBySchedule(packageName: String): Boolean {
        return try {
            val currentTime = Calendar.getInstance()
            val dayOfWeek = currentTime.get(Calendar.DAY_OF_WEEK) - 1
            val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
            val currentTimeStr = timeFormat.format(currentTime.time)

            // Get schedules synchronously for real-time checking
            val schedules = database.lockScheduleDao().getSchedulesForApp(packageName)
            // Since this is being called from a background thread, we need to handle this properly
            true // For now, return true. In production, implement proper schedule checking
        } catch (e: Exception) {
            Log.e(TAG, "Error checking schedule", e)
            false
        }
    }

    private fun lockApp(packageName: String) {
        val intent = Intent(this, AppLockedActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("lockedPackage", packageName)
        }
        startActivity(intent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
    }
}
