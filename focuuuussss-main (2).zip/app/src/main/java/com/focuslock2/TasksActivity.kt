package com.focuslock2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class TasksActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TasksScreen() }
    }
}

@Composable
fun TasksScreen() {
    val demoTasks = remember { listOf("Sweep the floor", "Wash the dishes", "Do an assignment") }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        items(demoTasks) { task ->
            Text(text = task, fontSize = 18.sp, modifier = Modifier.padding(8.dp))
        }
    }
}
