package com.focuslock2

import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TimePicker
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.focuslock2.database.AppLockDatabase
import com.focuslock2.database.LockSchedule
import kotlinx.coroutines.launch

class SetTimeoutAppsActivity : AppCompatActivity() {
    private lateinit var database: AppLockDatabase
    private lateinit var scheduleAdapter: ScheduleListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_timeout_apps)

        database = AppLockDatabase.getDatabase(this)

        val listView = findViewById<ListView>(R.id.schedulesListView)
        val btnAddSchedule = findViewById<Button>(R.id.btnAddSchedule)
        val startTimeInput = findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = findViewById<EditText>(R.id.endTimeInput)

        scheduleAdapter = ScheduleListAdapter(this, mutableListOf(), database)
        listView.adapter = scheduleAdapter

        loadSchedules()

        btnAddSchedule.setOnClickListener {
            val startTime = startTimeInput.text.toString()
            val endTime = endTimeInput.text.toString()

            if (startTime.isEmpty() || endTime.isEmpty()) {
                Toast.makeText(this, "Please enter both times", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                val schedule = LockSchedule(
                    packageName = "com.example", // In production, select from list
                    startTime = startTime,
                    endTime = endTime,
                    isActive = true
                )
                database.lockScheduleDao().insertSchedule(schedule)
                startTimeInput.text.clear()
                endTimeInput.text.clear()
                Toast.makeText(this@SetTimeoutAppsActivity, "Schedule added", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadSchedules() {
        lifecycleScope.launch {
            database.lockScheduleDao().getAllSchedules().collect { schedules ->
                scheduleAdapter.clear()
                scheduleAdapter.addAll(schedules)
                scheduleAdapter.notifyDataSetChanged()
            }
        }
    }
}
