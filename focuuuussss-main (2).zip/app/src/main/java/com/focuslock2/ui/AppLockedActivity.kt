package com.focuslock2

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AppLockedActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_locked)

        val lockedPackage = intent.getStringExtra("lockedPackage") ?: return

        val appNameView = findViewById<TextView>(R.id.lockedAppName)
        val appIconView = findViewById<ImageView>(R.id.lockedAppIcon)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val unlockButton = findViewById<Button>(R.id.unlockButton)
        val pointsDisplay = findViewById<TextView>(R.id.pointsDisplay)

        // Get app name and icon
        try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(lockedPackage, 0)
            val appName = pm.getApplicationLabel(appInfo).toString()
            val appIcon = pm.getApplicationIcon(lockedPackage)

            appNameView.text = "App Locked: $appName"
            appIconView.setImageDrawable(appIcon)
        } catch (e: PackageManager.NameNotFoundException) {
            appNameView.text = "App is locked"
        }

        // Master password for unlock
        val masterPassword = "1234"

        unlockButton.setOnClickListener {
            val enteredPassword = passwordInput.text.toString()
            if (enteredPassword == masterPassword) {
                Toast.makeText(this, "Unlocked!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Wrong password!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
