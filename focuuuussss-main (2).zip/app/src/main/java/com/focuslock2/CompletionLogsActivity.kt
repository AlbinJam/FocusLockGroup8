package com.focuslock2

import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class CompletionLogsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_completion_logs)

        val listView = findViewById<ListView>(R.id.logsListView)
        
        val logs = listOf(
            "2025-11-20: Sweep the floor — Completed",
            "2025-11-21: Wash the dishes — Completed",
            "2025-11-22: Do an assignment — Completed"
        )

        val adapter = LogsListAdapter(this, logs)
        listView.adapter = adapter
    }
}
